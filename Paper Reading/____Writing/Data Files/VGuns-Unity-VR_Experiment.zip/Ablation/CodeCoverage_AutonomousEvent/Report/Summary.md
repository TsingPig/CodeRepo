﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/5/28 - 19:29:37 |
| Parser: | MultiReportParser (24x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 8 |
| Files: | 8 |
| Covered lines: | 177 |
| Uncovered lines: | 95 |
| Coverable lines: | 272 |
| Total lines: | 782 |
| Line coverage: | 65% (177 of 272) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 23 |
| Total methods: | 36 |
| Method coverage: | 63.8% (23 of 36) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**177**|**95**|**272**|**782**|**65%**|**0**|**0**|****|**23**|**36**|**63.8%**|
|AudioManager|21|6|27|51|77.7%|0|0||2|2|100%|
|BulletTime|3|4|7|24|42.8%|0|0||1|2|50%|
|EnemyAi|34|39|73|154|46.5%|0|0||5|11|45.4%|
|Gun|45|19|64|320|70.3%|0|0||7|10|70%|
|Round|25|14|39|83|64.1%|0|0||2|2|100%|
|SpeedUpTime|3|3|6|22|50%|0|0||1|2|50%|
|TimeManager|7|8|15|29|46.6%|0|0||2|4|50%|
|XRTarget|39|2|41|99|95.1%|0|0||3|3|100%|
